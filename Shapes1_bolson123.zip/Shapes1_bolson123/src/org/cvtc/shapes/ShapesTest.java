package org.cvtc.shapes;

public class ShapesTest {
    public static void main(String[] args) {

        // Sphere object
        Sphere sphere = new Sphere(5);
        sphere.render();

        // Cuboid object
        Cuboid cuboid = new Cuboid(1, 2, 3);
        cuboid.render();

        //Cylinder object
        Cylinder cylinder = new Cylinder(1, 2);
        cylinder.render();
    }
}
