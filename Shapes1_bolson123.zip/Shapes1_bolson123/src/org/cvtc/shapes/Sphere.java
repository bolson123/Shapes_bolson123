package org.cvtc.shapes;

// imports
import javax.swing.*;

import static java.lang.Math.PI;

public class Sphere extends Shape {

    // variables
    private float radius = 0;

    // getters and setters
    public float getRadius() {
        return radius;
    }

    public void setRadius(float radius) {
        this.radius = radius;
    }

    //Default Constructor
    public Sphere() {
        setRadius(0);
    }

    // Overload Constructor
    public Sphere(float radius) {
        this.radius = radius;
    }

    // Implementation of methods
    // surface area method
    @Override
    public float surfaceArea() {
        float s = (float) (4 * PI * (float)Math.pow(radius, 2));
        return s;
    }

    // volume method
    @Override
    public float volume() {
        float v = (float) (1.33 * PI * Math.pow(radius, 3));
        return v;
    }

    // render method
    public void render() {
        String message = "Sphere\n\n";
        message += "Dimensions: \n";
        message += "radius = " + radius + "\n\n";
        message += "Surface Area = " + surfaceArea() + "units^2\n\n";
        message += "Volume = " + volume() + " units^3\n";

        JOptionPane.showMessageDialog(null, message);

    }
}
