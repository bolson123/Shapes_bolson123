package org.cvtc.shapes;

// Imports
import javax.swing.JOptionPane;

public class Cuboid extends Shape {

    // Variables
    private float width = 0;
    private float height = 0;
    private float depth = 0;

    // Getters and Setters
    public float getWidth() {
        return width;
    }

    private void setWidth(float width) {
        this.width = width;
    }

    public float getHeight() {
        return height;
    }

    private void setHeight(float height) {
        this.height = height;
    }

    public float getDepth() {
        return depth;
    }

    private void setDepth(float depth) {
        this.depth = depth;
    }

    //Default Constructor
    public Cuboid() {
        setWidth(0);
        setHeight(0);
        setDepth(0);
    }

    // Overload Constructor
    public Cuboid(float width, float height, float depth) {
        this.width = width;
        this.height = height;
        this.depth = depth;
    }

    // Implementation of methods
    // surface area method
    @Override
    public float surfaceArea() {
        float s = (2 * depth * width) + (2 * depth * height) + (2 * height * width);
        return s;
    }

    // volume method
    @Override
    public float volume() {
        float v = depth * width * height;
        return v;
    }

    // render method
    public void render() {
        String message = "Cuboid\n\n";
        message += "Dimensions: \n";
        message += "width = " + width + "\n\n";
        message += "height = " + height + "\n\n";
        message += "depth = " + depth + "\n\n";
        message += "Surface Area = " + surfaceArea() + " units^2\n\n";
        message += "Volume = " + volume() + " units^3\n";

        JOptionPane.showMessageDialog(null, message);
    }
}
