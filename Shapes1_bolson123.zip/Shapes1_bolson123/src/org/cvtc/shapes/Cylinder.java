package org.cvtc.shapes;

// Imported class
import static java.lang.Math.PI;
import javax.swing.JOptionPane;

public class Cylinder extends Shape {

    // variables
    private float radius = 0;
    private float height = 0;

    // getters and setters
    public float getRadius() {
        return radius;
    }

    private void setRadius(float radius) {
        this.radius = radius;
    }

    public float getHeight() {
        return height;
    }

    private void setHeight(float height) {
        this.height = height;
    }

    //Default Constructor
    public Cylinder() {
        setRadius(0);
        setHeight(0);
    }

    // Overload Constructor
    public Cylinder(float radius, float height) {
        this.radius = radius;
        this.height = height;
    }

    // Implementation of methods
    // surface area method
    @Override
    public float surfaceArea() {
        float s = (float) (2 * PI * radius * height + 2 * PI * Math.pow(radius, 2));
        return s;
    }

    // volume method
    @Override
    public float volume() {
        float v = (float) (PI * Math.pow(radius, 2) * height);
        return v;
    }

    // render method
    public void render() {
        String message = "Cylinder\n\n";
        message += "Dimensions: \n";
        message += "radius = " + radius + "\n\n";
        message += "height = " + height + "\n\n";
        message += "Surface Area = " + surfaceArea() + " units^2\n\n";
        message += "Volume = " + volume() + " units^3\n";

        JOptionPane.showMessageDialog(null, message);
    }
}
